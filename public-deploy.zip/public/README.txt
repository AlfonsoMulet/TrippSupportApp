TripPlanner Support Page
========================

This folder contains your support website files:
- index.html: Main support page
- support.html: Same support page (accessible at /support.html)

To deploy:
1. Drag this entire 'public' folder into Firebase Console
2. Or ZIP this folder and upload it

Your site will be live at:
https://trip-planner-app-a09e5.web.app
